# Install Dependencies

npm Install

# To run the project on local machine

npm run build:ssr
npm run serve:ssr
